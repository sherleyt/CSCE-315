package project1;

import java.util.*;

public class Table {
    Hashtable<String,Object> columns;
    List<String> columnOrder;
    List<String> primaryKeys; //Which columns-indexes are keys
    HashSet<Hashtable<String,Object>> entries; //List of Column-Data


    public Table(){
        columns = new Hashtable<>();
        columnOrder = new ArrayList<>();
        primaryKeys = new ArrayList<>();
        entries = new HashSet<>();
    }

    public boolean AddColumn(String name, Object dataType){
        for (String c: columnOrder)
            if (c == name)
                return false;

        columns.put(name,dataType);
        columnOrder.add(name);
        return true;
    }

    public boolean AddEntry(Object... values){

        //Check if input can hold primary key indexes;
        for (String key: primaryKeys)
            if (values.length < columnOrder.indexOf(key))
                return false;

        //Check if input primary keys clash with existing ones
        for (Hashtable<String,Object> entry: entries){
            boolean matching = true;
            for (String key : primaryKeys){
                if (entry.get(key).equals(values[columnOrder.indexOf(key)]))
                    matching = false;
            }
            if (matching)
                return false;
        }

        //Check if input matches column datatypes
        //IMPLEMENT THIS

        //Add entry
        Hashtable<String,Object> newEntry = new Hashtable<>();
        for (int i = 0; i < values.length && i < columnOrder.size(); i++){
            newEntry.put(columnOrder.get(i),values[i]);
        }
        return true;
    }
}
