package project1;

import java.util.*;

public class Dbms {
    Hashtable<String,Table> tables;
    public Dbms(){

    }

    public boolean AddTable(String name,Table table){
        tables.put(name, table);
        return true;
    }
}
